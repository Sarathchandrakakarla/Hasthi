-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: mywebserver-database.c7h1qkwyxtrl.ap-south-2.rds.amazonaws.com    Database: logistics
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add permission',1,'add_permission'),(2,'Can change permission',1,'change_permission'),(3,'Can delete permission',1,'delete_permission'),(4,'Can view permission',1,'view_permission'),(5,'Can add group',2,'add_group'),(6,'Can change group',2,'change_group'),(7,'Can delete group',2,'delete_group'),(8,'Can view group',2,'view_group'),(9,'Can add user',3,'add_user'),(10,'Can change user',3,'change_user'),(11,'Can delete user',3,'delete_user'),(12,'Can view user',3,'view_user'),(13,'Can add content type',4,'add_contenttype'),(14,'Can change content type',4,'change_contenttype'),(15,'Can delete content type',4,'delete_contenttype'),(16,'Can view content type',4,'view_contenttype'),(17,'Can add session',5,'add_session'),(18,'Can change session',5,'change_session'),(19,'Can delete session',5,'delete_session'),(20,'Can view session',5,'view_session'),(21,'Can add user',6,'add_user'),(22,'Can change user',6,'change_user'),(23,'Can delete user',6,'delete_user'),(24,'Can view user',6,'view_user'),(25,'Can add places',7,'add_places'),(26,'Can change places',7,'change_places'),(27,'Can delete places',7,'delete_places'),(28,'Can view places',7,'view_places'),(29,'Can add bookings',8,'add_bookings'),(30,'Can change bookings',8,'change_bookings'),(31,'Can delete bookings',8,'delete_bookings'),(32,'Can view bookings',8,'view_bookings'),(33,'Can add driver',9,'add_driver'),(34,'Can change driver',9,'change_driver'),(35,'Can delete driver',9,'delete_driver'),(36,'Can view driver',9,'view_driver');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) COLLATE utf8mb4_general_ci NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) COLLATE utf8mb4_general_ci NOT NULL,
  `first_name` varchar(150) COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(150) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(254) COLLATE utf8mb4_general_ci NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookings` (
  `S_No` int NOT NULL AUTO_INCREMENT,
  `Order_Id` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `Username` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `Source` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `Destination` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `Date` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `Time` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `No_Of_Persons` int NOT NULL,
  `Allocated_Persons` int NOT NULL DEFAULT '0',
  `Admin_Accept_Status` int NOT NULL DEFAULT '0',
  `Pay_Status` int NOT NULL DEFAULT '0',
  `Refund_Status` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Journey_Status` enum('Ongoing','Cancelled','Completed','Rejected') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Ongoing',
  `Bus_No` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Code` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Verify_Status` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Completion_Status` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`S_No`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES (1,'hst_50vym','USER','VIT Chennai','SRM University','2023-11-23','09:15',1,0,0,0,NULL,'Cancelled',NULL,NULL,'Not_Verified',NULL),(2,'hst_yt3q2','USER','VIT Chennai','Bharath University','2023-11-27','09:00',1,0,1,0,NULL,'Cancelled',NULL,NULL,'Not_Verified',NULL),(3,'hst_lcfwp','USER','SRM University','Bharath University','2023-11-27','10:00',1,0,0,0,NULL,'Rejected',NULL,NULL,'Not_Verified',NULL),(4,'hst_5jplx','USER','VIT Chennai','SRM University','2023-12-11','10:00',2,0,1,1,NULL,'Ongoing',NULL,NULL,'Not_Verified',NULL),(7,'hst_plz8s','USER','Bharath University','VIT Chennai','2023-12-14','19:00',3,3,1,1,NULL,'Ongoing','2-AP05 GK 5003,1-AP04 BK 2205','48093-AP05 GK 5003,99462-AP04 BK 2205','Not_Verified-AP05 GK 5003,Not_Verified-AP04 BK 2205','Not_Completed-AP05 GK 5003,Not_Completed-AP04 BK 2205'),(8,'hst_zh4fq','AKSHAW','VIT Chennai','PHEONIX MALL ','2023-12-18','10:30',5,0,0,0,NULL,'Cancelled',NULL,NULL,NULL,NULL),(9,'hst_d6rxt','AKSHAW','VIT Chennai','PHEONIX MALL ','2023-12-24','09:00',5,0,0,0,NULL,'Cancelled',NULL,NULL,NULL,NULL),(10,'hst_q2ldx','AKSHAW','VIT Chennai','PHEONIX MALL ','2023-12-20','11:00',3,0,1,0,NULL,'Ongoing',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `model` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (2,'auth','group'),(1,'auth','permission'),(3,'auth','user'),(4,'contenttypes','contenttype'),(8,'home','bookings'),(9,'home','driver'),(7,'home','places'),(6,'home','user'),(5,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2023-09-08 08:59:52.364018'),(2,'contenttypes','0002_remove_content_type_name','2023-09-08 08:59:53.013870'),(3,'auth','0001_initial','2023-09-08 09:00:00.398464'),(4,'auth','0002_alter_permission_name_max_length','2023-09-08 09:00:01.446981'),(5,'auth','0003_alter_user_email_max_length','2023-09-08 09:00:01.509835'),(6,'auth','0004_alter_user_username_opts','2023-09-08 09:00:01.539062'),(7,'auth','0005_alter_user_last_login_null','2023-09-08 09:00:01.891122'),(8,'auth','0006_require_contenttypes_0002','2023-09-08 09:00:01.941262'),(9,'auth','0007_alter_validators_add_error_messages','2023-09-08 09:00:01.994435'),(10,'auth','0008_alter_user_username_max_length','2023-09-08 09:00:02.102093'),(11,'auth','0009_alter_user_last_name_max_length','2023-09-08 09:00:02.215948'),(12,'auth','0010_alter_group_name_max_length','2023-09-08 09:00:02.528483'),(13,'auth','0011_update_proxy_permissions','2023-09-08 09:00:02.566685'),(14,'auth','0012_alter_user_first_name_max_length','2023-09-08 09:00:02.647932'),(15,'home','0001_initial','2023-09-08 09:00:02.762063'),(16,'home','0002_alter_user_email_alter_user_mobile','2023-09-08 09:00:03.248144'),(17,'home','0003_places','2023-09-08 09:00:03.480121'),(18,'home','0004_places_nearby','2023-09-08 09:00:04.506390'),(19,'home','0005_user_full_name','2023-09-08 09:00:04.558922'),(20,'home','0006_user_dob','2023-09-08 09:00:04.621685'),(21,'sessions','0001_initial','2023-09-08 09:00:04.838975'),(22,'home','0007_bookings','2023-09-22 13:50:33.234550'),(23,'home','0008_bookings_pay_status','2023-09-25 15:10:19.885922'),(24,'home','0009_alter_bookings_pay_status','2023-09-25 15:11:07.536885'),(25,'home','0010_bookings_accept_status_alter_bookings_pay_status','2023-09-25 16:42:23.987497'),(26,'home','0011_rename_accept_status_bookings_admin_accept_status_and_more','2023-10-25 04:24:47.791783'),(27,'home','0012_bookings_order_id','2023-10-31 04:44:21.196875'),(28,'home','0013_alter_bookings_order_id','2023-10-31 04:44:47.642653'),(29,'home','0014_bookings_journey_status','2023-10-31 05:06:03.216453'),(30,'home','0015_alter_bookings_journey_status','2023-10-31 08:23:21.380749'),(31,'home','0016_alter_bookings_journey_status','2023-10-31 08:44:45.609063'),(32,'home','0017_remove_bookings_cust_accept_status','2023-11-24 04:19:59.869693'),(33,'home','0018_driver_bookings_bus_no_bookings_code_and_more','2023-12-09 12:42:56.714042'),(34,'home','0019_bookings_no_of_persons','2023-12-11 07:23:17.836861'),(35,'home','0020_remove_user_dob','2023-12-11 10:05:31.588740'),(36,'home','0021_bookings_allocated_persons','2023-12-12 17:08:21.711106'),(37,'home','0022_driver_available_seats','2023-12-13 11:06:20.209997'),(38,'home','0023_alter_bookings_verify_status','2023-12-13 12:49:18.957302'),(39,'home','0024_bookings_completion_status_and_more','2023-12-13 13:39:40.496870'),(40,'home','0025_bookings_refund_status','2023-12-13 15:46:30.633815');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) COLLATE utf8mb4_general_ci NOT NULL,
  `session_data` longtext COLLATE utf8mb4_general_ci NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('23lr8d9ruifwcg8m0myk56awllqndlez','.eJyrVgotTi3KS8xNVbJSCg12DVLSUXIrzcmJ94MIBScWJZZkJGck5qUUJSoEpaakABW45iZm5gAlsxOzE4tyEvMS8zJNHNJBgnrJ-blABb75SZk5IO2Wpoam5iYmFhYmQFEXfyegkJGFroGlrpGBgYlSLQAT4yW_:1qnwCl:C1omvS6MtPtl75VmsgSov3bjF6PB-C6xO2BgcxkHnsA','2023-10-18 07:21:59.194984'),('44n9of9vap7q4k66roio1js4dlwsxn23','.eJyrVnIrzcmJ90vMTVWyUgpOLEosyUjOSMxLKUpUCEpNSalU0lFyzU3MzAHKZidmJxblJOYl5mWaOKSDBPWS83OBCnzzkzJzQPotTQ1NzU1MLCxMgKIu_k5AISMLXQNLXSMDA5BQaHFqUR7EqtBg1yClWgA-9yY4:1r0jSa:8VHVyNREANOTWnr9-vyEM6uwjrw6bW59c_-u6Yw6OXQ','2023-11-22 14:23:12.121334'),('499khwfl0kbead3nm4fm1foaz5ez3pl8','NDZjM2M2ZDhiYmQ1ODk0MjA3OTI5MjdiMTg2MThiN2ZjMDY1ZjYwMTp7IlVzZXJuYW1lIjoiSEFSU0hJVEhBIFJFRERZICIsIkZ1bGxfTmFtZSI6IkJBVEhJTkEgSEFSU0hJVEhBIFJFRERZIiwiRW1haWwiOiJoYXJzaGl0aGFiYXRoaW5hMjVAZ21haWwuY29tIiwiTW9iaWxlIjoiNzAzNjA5MzI1MyIsIlBhc3N3b3JkIjoiaGFyc2hpdGhhQDI2In0=','2024-01-02 16:01:54.692377'),('6hu717dlc5vj8yulqhnb2kel3syr8448','eyJGdWxsX05hbWUiOiJTYXJhdGhjaGFuZHJhIFJlZGR5IiwiRW1haWwiOiJrYWthcmxhbmFuaTRAZ21haWwuY29tIiwiTW9iaWxlIjoiOTUxNTc0NDg4NCIsIlBhc3N3b3JkIjoiS3NjciJ9:1rDRu5:yTNoHZai_zW6ejp2KgrvQEHWf95WYF89V6wABPh83vE','2023-12-27 16:16:09.562419'),('8n95umbh5033b6iou2x3u8dvnhpscc75','.eJyrVgotTi3KS8xNVbJSCg12DVLSUXIrzcmJ94MIBScWJZZkJGck5qUUJSoEpaakVAJVuOYmZuYAZbMTsxOLchLzEvMyTRzSQYJ6yfm5QAW--UmZOSD9lqaGpuYmJhYWJkBRF38noJCRha6Bpa6RgYGJUi0ASRcmOA:1qyycx:NjXxCwb5SmSEI4hVmlwA0FR6j2kowXw3dweJVEHrDa4','2023-11-17 18:10:39.297446'),('97tvvs87p67d0bqpz4zhr4moa49104y5','eyJGdWxsX05hbWUiOiJTYXJhdGhjaGFuZHJhIFJlZGR5IiwiRW1haWwiOiJrYWthcmxhbmFuaTRAZ21haWwuY29tIiwiTW9iaWxlIjoiOTUxNTc0NDg4NCIsIlBhc3N3b3JkIjoiS3NjciJ9:1rD6lE:CFCk9LzTcsMlD_ImoL95taUfo1vD5F9Px9urm64KV-M','2023-12-26 17:41:36.994434'),('a0y7wypvs0rc589p2eum8o6kffbafxae','eyJGdWxsX05hbWUiOiJTYXJhdGhjaGFuZHJhIFJlZGR5IiwiRW1haWwiOiJrYWthcmxhbmFuaTRAZ21haWwuY29tIiwiTW9iaWxlIjoiOTUxNTc0NDg4NCIsIkRPQiI6IjI4LTA5LTIwMDQifQ:1qjyEF:sLqSH6uBCM4gQguNCi7h3tqa2NqUkg649JMQz_S-NSg','2023-10-07 08:43:07.228638'),('a9fm5fwoluey31fpbaqtro48h0wrs12d','.eJyrVgotTi3KS8xNVbJSCg12DVLSUXIrzcmJ94MIBScWJZZkJGck5qUUJSoEpaakVAJVuOYmZuYAZbMTsxOLchLzEvMyTRzSQYJ6yfm5QAW--UmZOSD9lqaGpuYmJhYWJkBRF38noJCRha6Bpa6RgYGJUi0ASRcmOA:1r0Nks:2djSf8_nCJlgrFUFEORz7uuWDA8DzCJ5AZvX-8s-oTQ','2023-11-21 15:12:38.925438'),('aiqncis2p645vogfoxejr8yawl4hvjet','.eJyrVgotTi3KS8xNVbJSCg12DVLSUXIrzcmJ94MIBScWJZZkJGck5qUUJSoEpaakABW45iZm5gAlsxOzE4tyEvMS8zJNHNJBgnrJ-blABb75SZk5IO2Wpoam5iYmFhYmQFEXfyegkJGFroGlrpGBgYlSLQAT4yW_:1qpqbc:nz_N0GdhVzwhqU9-WvAX1btVGefcyXq7EasUnKf_Y8M','2023-10-23 13:47:32.682697'),('bc8u0o79r692ega5ea9ypsvl9vpglqnh','eyJGdWxsX05hbWUiOiJTYXJhdGhjaGFuZHJhIFJlZGR5IiwiRW1haWwiOiJrYWthcmxhbmFuaTRAZ21haWwuY29tIiwiTW9iaWxlIjoiOTUxNTc0NDg4NCIsIlBhc3N3b3JkIjoiS3NjciJ9:1rDfkw:PfBPOSzcR5WcAGB3HpZbFHjkU6zKPcR4vXJ64K9Pe2E','2023-12-28 07:03:38.923840'),('chbjkfelsyg628zych4sucyzjdyyzky7','.eJyrVnIrzcmJ90vMTVWyUgpOLEosyUjOSMxLKUpUCEpNSalU0lFyzU3MzAHKZidmJxblJOYl5mWaOKSDBPWS83OBCnzzkzJzQPotTQ1NzU1MLCxMgKIu_k5KVnlA03WUAhKLi8vzi1KASryLk4uUagE81CYj:1rCjaC:zvKbVA_1PJuDzgc4wXel2s7WOU4Ynnf6D8p_MSbkN0g','2023-12-25 16:56:40.854000'),('cqm5d441zg067plzxikjkmxekj1r7nci','ZWFiMjA3OGI0ZGYwNzkyZDNjYmU3ZjMyZDc4Y2RiNWY0MzFjMzVkZjp7IkZ1bGxfTmFtZSI6IlNhcmF0aGNoYW5kcmEgUmVkZHkiLCJFbWFpbCI6Imtha2FybGFuYW5pNEBnbWFpbC5jb20iLCJNb2JpbGUiOiI5NTE1NzQ0ODg0IiwiUGFzc3dvcmQiOiJLc2NyIiwiVXNlcm5hbWUiOiJTQVJBVEgifQ==','2024-01-04 15:13:14.015575'),('cxqhnlyc3rb75ahng4c1rp49y8tse7ij','eyJGdWxsX05hbWUiOiJTYXJhdGhjaGFuZHJhIiwiRW1haWwiOiJrYWthcmxhbmFuaTRAZ21haWwuY29tIiwiTW9iaWxlIjoiOTUxNTc0NDg4NCIsIlBhc3N3b3JkIjoiS3NjciJ9:1rCwT3:-g1u3nIXuxoTtLv6rrIMNMDdoW2RTggbQ54vbH0E7RU','2023-12-26 06:42:09.784812'),('dlnepftyu2mrcgro9sf59uvfhndxf9wc','.eJyrVnIrzcmJ90vMTVWyUgpOLEosyUjOSMxLKUpUCEpNSalU0lFyzU3MzAHKZidmJxblJOYl5mWaOKSDBPWS83OBCnzzkzJzQPotTQ1NzU1MLCxMgKIu_k5AISMLXQNLXSMDA5BQaHFqUR7EqtBg1yClWgA-9yY4:1qvt3L:OCmdn056vvJLt1YcWK0LfyD8ppnw112LvY2SyGlCDDI','2023-11-09 05:37:07.456485'),('dqu6x7y4ri8n06wysd8najgo1uhdrxcq','eyJGdWxsX05hbWUiOiJTYXJhdGhjaGFuZHJhIFJlZGR5IiwiRW1haWwiOiJrYWthcmxhbmFuaTRAZ21haWwuY29tIiwiTW9iaWxlIjoiOTUxNTc0NDg4NCIsIkRPQiI6IjI4LTA5LTIwMDQifQ:1qjiby:G0L1P7V9OcjsWjCrl_CXw_7teC_OhMj9xo8w84IX588','2023-10-06 16:02:34.235097'),('e7q24wyf575slhev5b82oqqu9ajbwvue','ZWFiMjA3OGI0ZGYwNzkyZDNjYmU3ZjMyZDc4Y2RiNWY0MzFjMzVkZjp7IkZ1bGxfTmFtZSI6IlNhcmF0aGNoYW5kcmEgUmVkZHkiLCJFbWFpbCI6Imtha2FybGFuYW5pNEBnbWFpbC5jb20iLCJNb2JpbGUiOiI5NTE1NzQ0ODg0IiwiUGFzc3dvcmQiOiJLc2NyIiwiVXNlcm5hbWUiOiJTQVJBVEgifQ==','2024-01-02 13:44:07.482147'),('euzhg065b7ng3ku8t31yh9wlx963zlsp','.eJyrVgotTi3KS8xNVbJSCg12DVLSUXIrzcmJ94MIBScWJZZkJGck5qUUJSoEpaakVAJVuOYmZuYAZbMTsxOLchLzEvMyTRzSQYJ6yfm5QAW--UmZOSD9lqaGpuYmJhYWJkBRF38nJas8oOm1ACJTJbw:1r5hgo:1IHI50BR7bkyMCToTSFpItPd1cgfOmuvLuEYI78OfsE','2023-12-06 07:30:26.193308'),('fsa1chy9x3nxirix2niww8ug9qtfm34s','.eJyrVgotTi3KS8xNVbJSCg12DVLSUXIrzcmJ94MIBScWJZZkJGck5qUUJSoEpaakVAJVuOYmZuYAZbMTsxOLchLzEvMyTRzSQYJ6yfm5QAW--UmZOSD9lqaGpuYmJhYWJkBRF38noJCRha6Bpa6RgYGJUi0ASRcmOA:1qkkWl:Tf2F_mzlDLSkYgLfy7Suj0KEgq1HMsVvTN7fEr0vaRI','2023-10-09 12:17:27.868646'),('h6qpkui3ay6u5tv4oqqia13787fntbkd','.eJyrVgotTi3KS8xNVbJSCg12DVLSUXIrzcmJ94MIBScWJZZkJGck5qUUJSoEpaakVAJVuOYmZuYAZbMTsxOLchLzEvMyTRzSQYJ6yfm5QAW--UmZOSD9lqaGpuYmJhYWJkBRF38nJas8oOm1ACJTJbw:1r5JZU:1pSsNwd2m1-G0Y4iTY_dZk91weWXVRfK1SAeYKQLKeI','2023-12-05 05:45:16.067174'),('hiv3z97h09pcb9sihl3dtftpdxhzlzyk','.eJyrVnIrzcmJ90vMTVWyUgpOLEosyUjOSMxLKUpUCEpNSalU0lFyzU3MzAHKZidmJxblJOYl5mWaOKSDBPWS83OBCnzzkzJzQPotTQ1NzU1MLCxMgKIu_k5AISMLXQNLXSMDA5BQaHFqUR7EqtBg1yClWgA-9yY4:1r0Ndx:lK1xSb-HVrVfvccOf59Qn7TBL0lIa2FkpNTqEx1-kvk','2023-11-21 15:05:29.641703'),('i63tbvn4w0z65gvjmd7yt39p340q8csh','eyJGdWxsX05hbWUiOiJTYXJhdGhjaGFuZHJhIFJlZGQiLCJFbWFpbCI6Imtha2FybGFuYW5pNEBnbWFpbC5jb20iLCJNb2JpbGUiOiI5NTE1NzQ0ODg0IiwiRE9CIjoiMjgtMDktMjAwNCJ9:1qmDDr:F2TECvO1Gmp1iXTEPwtcaSN2HyY9MnoGif8bYNUsxK0','2023-10-13 13:07:59.459394'),('jag9bi79g6nh432p0smhvg47emg9soel','.eJyrVgotTi3KS8xNVbJScvQO9nAMV9JRcivNyYn3gwpmF2ckVioEpaakVAKlXHMTM3OAwrmlyRmpOZmJYFm9IpCskYGRoUNZZklxSWlKal6JXmKyXmYeUItvflJmDsgoCzMLCxNTUyAFFA1ILC4uzy9KAYoHFafkJRblJqY4GBop1QIA1NovVg:1rF5Zt:absaJZuBQHagcvRcnQDGgh_2zZcFCdCwU-Q21-i-xPc','2024-01-01 04:50:05.336334'),('krgc4i010z7j1fuq4de2zpfkxf3to27h','.eJyrVnIrzcmJ90vMTVWyUgpOLEosyUjOSMxLKUpUCEpNSalU0lFyzU3MzAHKZidmJxblJOYl5mWaOKSDBPWS83OBCnzzkzJzQPotTQ1NzU1MLCxMgKIu_k5AISMLXQNLXSMDA5BQaHFqUR7EqtBg1yClWgA-9yY4:1qfJAE:dA6r8FQukagmQXegdd3qGGYmX__5ap_fHeq7tR-zFDM','2023-09-24 12:03:42.502020'),('lrm2l3nwc7bc8hj7vmlv7tgm0ienyybb','.eJyrVnIrzcmJ90vMTVWyUgpOLEosyUjOSMxLKUpUCEpNSalU0lFyzU3MzAHKZidmJxblJOYl5mWaOKSDBPWS83OBCnzzkzJzQPotTQ1NzU1MLCxMgKIu_k5AISMLXQNLXSMDA5BQaHFqUR7EqtBg1yClWgA-9yY4:1qjEsH:urZ2CIgrdEyXXSHNNbLlK65WKLx_xws7Kox4xNpePh4','2023-10-05 08:17:25.451167'),('mhehdo0eejb3vkaz6n6n81xn6onx6iw5','eyJGdWxsX05hbWUiOiJTYXJhdGhjaGFuZHJhIFJlZGR5IiwiRW1haWwiOiJrYWthcmxhbmFuaTRAZ21haWwuY29tIiwiTW9iaWxlIjoiOTUxNTc0NDg4NCIsIkRPQiI6bnVsbH0:1r3JU0:xAlNksuKZ_JweE8-TsHoHfuwtCXy7QJ9hiYnedhfcYw','2023-11-29 17:15:20.795616'),('mwdgy0p5jsevduzgdun9n77ubh6b11t0','.eJyrVnIrzcmJ90vMTVWyUgpOLEosyUjOSMxLKUpUCEpNSalU0lFyzU3MzAHKZidmJxblJOYl5mWaOKSDBPWS83OBCnzzkzJzQPotTQ1NzU1MLCxMgKIu_k5KVnlA03WUQotTi_KgVjgGOYZ4KNUCAIawJkA:1qu61H:Biv3m-7GgSKsVEqA3GzmnDbgWDa0-YQffDrNOQw6YJA','2023-11-04 07:03:35.017216'),('ncayzayr78g0g9g3jwp4vxp4h7y0vjpw','.eJyrVnIrzcmJ90vMTVWyUgpOLEosyUjOSMxLKUpUCEpNSalU0lFyzU3MzAHKZidmJxblJOYl5mWaOKSDBPWS83OBCnzzkzJzQPotTQ1NzU1MLCxMgKIu_k5AISMLXQNLXSMDA5BQaHFqUR7EqtBg1yClWgA-9yY4:1qwm8W:iMtgClCsnLKWqPIBLM3lP4SoeUse0NPn_X0_HxdzYco','2023-11-11 16:26:08.645599'),('njemouxdeh9gbosgyxzl5r1hn23jgtpo','YTc1MWFiYTZkN2NmZTgzMjYzOGU0Mzc0N2ZkNWUyZGQwZDhkNTNkNzp7IkZ1bGxfTmFtZSI6IlNhcmF0aGNoYW5kcmEgUmVkZHkiLCJFbWFpbCI6Imtha2FybGFuYW5pNEBnbWFpbC5jb20iLCJNb2JpbGUiOiI5NTE1NzQ0ODg0IiwiUGFzc3dvcmQiOiJLc2NyIn0=','2024-01-02 09:27:26.506687'),('nvv8i9yszga183ee7kttlg4b5u30mqox','.eJyrVgotTi3KS8xNVbJSCg12DVLSUXIrzcmJ94MIBScWJZZkJGck5qUUJSoEpaakVAJVuOYmZuYAZbMTsxOLchLzEvMyTRzSQYJ6yfm5QAW--UmZOSD9lqaGpuYmJhYWJkBRF38nJas8oOm1ACJTJbw:1r4xIQ:PD3BJ238_0_6dFZiQHV3ujJdHjih6XDXTnfZ19ezR2I','2023-12-04 05:58:10.870565'),('pstaqtgxctn6uvkdr9q4n97sx0i4e5fb','YTc1MWFiYTZkN2NmZTgzMjYzOGU0Mzc0N2ZkNWUyZGQwZDhkNTNkNzp7IkZ1bGxfTmFtZSI6IlNhcmF0aGNoYW5kcmEgUmVkZHkiLCJFbWFpbCI6Imtha2FybGFuYW5pNEBnbWFpbC5jb20iLCJNb2JpbGUiOiI5NTE1NzQ0ODg0IiwiUGFzc3dvcmQiOiJLc2NyIn0=','2024-01-02 07:28:57.169122'),('s3199q3l3yt77wxl9y23b84jowd3ii83','YTc1MWFiYTZkN2NmZTgzMjYzOGU0Mzc0N2ZkNWUyZGQwZDhkNTNkNzp7IkZ1bGxfTmFtZSI6IlNhcmF0aGNoYW5kcmEgUmVkZHkiLCJFbWFpbCI6Imtha2FybGFuYW5pNEBnbWFpbC5jb20iLCJNb2JpbGUiOiI5NTE1NzQ0ODg0IiwiUGFzc3dvcmQiOiJLc2NyIn0=','2024-01-02 10:36:28.381406'),('spvxfze41hoh9aka34m7lfohh4tjr3lx','YTc1MWFiYTZkN2NmZTgzMjYzOGU0Mzc0N2ZkNWUyZGQwZDhkNTNkNzp7IkZ1bGxfTmFtZSI6IlNhcmF0aGNoYW5kcmEgUmVkZHkiLCJFbWFpbCI6Imtha2FybGFuYW5pNEBnbWFpbC5jb20iLCJNb2JpbGUiOiI5NTE1NzQ0ODg0IiwiUGFzc3dvcmQiOiJLc2NyIn0=','2024-01-02 15:52:12.773278'),('sxg6m71zmiiswum8hrbd0txevr1y2u6t','.eJyrVgotTi3KS8xNVbJSCg12DVLSUXIrzcmJ94MIBScWJZZkJGck5qUUJSoEpaakVAJVuOYmZuYAZbMTsxOLchLzEvMyTRzSQYJ6yfm5QAW--UmZOSD9lqaGpuYmJhYWJkBRF38nJas8oOm1ACJTJbw:1r552i:vesxzk5oL3q5Kb-d_2Bx5tC_IoNm7Iw3AaT6uMl5Z-s','2023-12-04 14:14:28.344861'),('tqi08umqcvanwg0bcqup9mcbivum5k68','eyJGdWxsX05hbWUiOiJTYXJhdGhjaGFuZHJhIFJlZGR5IiwiRW1haWwiOiJrYWthcmxhbmFuaTRAZ21haWwuY29tIiwiTW9iaWxlIjoiOTUxNTc0NDg4NCIsIkRPQiI6IjI4LTA5LTIwMDQifQ:1qfNrT:_8edyIK2k0fKN-30gZv8mD4kxeUscY47LPF6TWWbnSI','2023-09-24 17:04:39.980398'),('ulnpxzw63f2kvyqbw32ciztfpk862fc8','.eJyrVgotTi3KS8xNVbJSCg12DVLSUXIrzcmJ94MIBScWJZZkJGck5qUUJSoEpaakVAJVuOYmZuYAZbMTsxOLchLzEvMyTRzSQYJ6yfm5QAW--UmZOSD9lqaGpuYmJhYWJkBRF38nJas8oOm1ACJTJbw:1rBwgs:9Jh3ZfZrZucoyVV2fxo1aXmcGznK8iPHQVIabqHJXMo','2023-12-23 12:44:18.961377'),('uw63hnckks8rl78n3bw7ot7dd9wcpmhv','.eJyrVgotTi3KS8xNVbJSCg12DVLSUXIrzcmJ94MIBScWJZZkJGck5qUUJSoEpaakABW45iZm5gAlsxOzE4tyEvMS8zJNHNJBgnrJ-blABb75SZk5IO2Wpoam5iYmFhYmQFEXfyegkJGFroGlrpGBgYlSLQAT4yW_:1qlMvv:8F1jyHmD3lH9aNZH5WIV7iLkqr6iM8VzxsQrbfuj9T0','2023-10-11 05:17:59.369670'),('v70o5o7h1yi11hnzb7atxbouwimmr95t','ZWFiMjA3OGI0ZGYwNzkyZDNjYmU3ZjMyZDc4Y2RiNWY0MzFjMzVkZjp7IkZ1bGxfTmFtZSI6IlNhcmF0aGNoYW5kcmEgUmVkZHkiLCJFbWFpbCI6Imtha2FybGFuYW5pNEBnbWFpbC5jb20iLCJNb2JpbGUiOiI5NTE1NzQ0ODg0IiwiUGFzc3dvcmQiOiJLc2NyIiwiVXNlcm5hbWUiOiJTQVJBVEgifQ==','2024-01-02 16:06:37.385326'),('vtfqpxjjqvb0zodavmrzo2xb99cc3dkx','.eJyrVnIrzcmJ90vMTVWyUgpOLEosyUjOSMxLKUpUCEpNSalU0lFyzU3MzAHKZidmJxblJOYl5mWaOKSDBPWS83OBCnzzkzJzQPotTQ1NzU1MLCxMgKIu_k5KVnlA03WUQotTi_IgVoQGuwYp1QIAOuMlvA:1r6Obf:SSc6Py_FhNfS7WZOJ8OF2y1pxShzsobX09k_-aC_7Kk','2023-12-08 05:19:59.047316'),('x4x5re1durv9k8v5k136w5056w1bhugq','eyJGdWxsX05hbWUiOiJTYXJhdGhjaGFuZHJhIFJlZGR5IiwiRW1haWwiOiJrYWthcmxhbmFuaTRAZ21haWwuY29tIiwiTW9iaWxlIjoiOTUxNTc0NDg4NCIsIlBhc3N3b3JkIjoiS3NjciJ9:1rEqKf:rU7r5s1y8Y2B25EvwZwSh6shEcMU0dx7Wu0dEOPVaeM','2023-12-31 12:33:21.931565'),('z17kd6j6ri1lbqj54gtmfb5t0zxuxtbv','eyJGdWxsX05hbWUiOiJTYXJhdGhjaGFuZHJhIFJlZGR5IiwiRW1haWwiOiJrYWthcmxhbmFuaTRAZ21haWwuY29tIiwiTW9iaWxlIjoiOTUxNTc0NDg4NCIsIkRPQiI6bnVsbH0:1r2Zrd:nfjhbJEoSe6vgEvw-Hjo8iPzZJyucKJz0tzItbS4ENk','2023-11-27 16:32:41.206780'),('zg597fv3ye557su2mcj7w2so8uprs7rn','eyJGdWxsX05hbWUiOiJTYXJhdGhjaGFuZHJhIFJlZGR5IiwiRW1haWwiOiJrYWthcmxhbmFuaTRAZ21haWwuY29tIiwiTW9iaWxlIjoiOTUxNTc0NDg4NCIsIkRPQiI6IjI4LTA5LTIwMDQifQ:1qeXjS:mdu0jSlLoAoKyMUprDMPrqI2FI3eN6hZ-WgjoPHMCQI','2023-09-22 09:24:54.554752');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `driver`
--

DROP TABLE IF EXISTS `driver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `driver` (
  `S_No` int NOT NULL AUTO_INCREMENT,
  `Username` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `Status` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `Bus_No` varchar(25) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Status_Time` date NOT NULL,
  `Current_Location` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Available_Seats` int NOT NULL DEFAULT '12',
  PRIMARY KEY (`S_No`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `driver`
--

LOCK TABLES `driver` WRITE;
/*!40000 ALTER TABLE `driver` DISABLE KEYS */;
INSERT INTO `driver` VALUES (5,'DRIVER','Available','AP05 GK 5003','2023-12-19',NULL,9),(6,'DRIVER2','Available','AP04 BK 2205','2023-12-14',NULL,11);
/*!40000 ALTER TABLE `driver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `S_No` int NOT NULL,
  `Booking_Id` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `Username` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `Amount` int NOT NULL,
  `DOP` varchar(20) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `places`
--

DROP TABLE IF EXISTS `places`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `places` (
  `S_No` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Nearby` longtext COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`S_No`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `places`
--

LOCK TABLES `places` WRITE;
/*!40000 ALTER TABLE `places` DISABLE KEYS */;
INSERT INTO `places` VALUES (1,'VIT Chennai',NULL),(2,'SRM University',NULL),(3,'Bharath University',NULL),(4,'Hindustan University',NULL);
/*!40000 ALTER TABLE `places` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `S_No` int NOT NULL AUTO_INCREMENT,
  `Username` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `Full_Name` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Password` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `Email` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Mobile` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Role` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `Pass_Hash` varchar(256) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`S_No`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'SARATH','Sarathchandra Reddy','Kscr','kakarlanani4@gmail.com','9515744884','Admin','pbkdf2_sha256$600000$008z16SZl5FZfWPilnETby$8JaoNhpCTcUqZvCV9cXKSnno7jPvHDGThnUp+WUYEEI='),(2,'USER','Sarathchandra Reddy','Kscr','kakarlanani4@gmail.com','9515744884','User','pbkdf2_sha256$600000$HaLHkr4hJqm2D27xxiXXMw$IUsP/4wY057aN3NPIcHLBJIL3Jxy/b8CKGpA/Dm1bOU='),(7,'DRIVER','Sarathchandra','Kscr','kakarlanani4@gmail.com','9515744884','Driver','pbkdf2_sha256$600000$1Z8Wt9vdC947b8LYcM1zIg$GrZgbKTEy5BfRzTXdBETC7NvvXwC8FLKLX1R6DaJIxY='),(8,'DRIVER2','Sarath','Kscr','kakarlanani4@gmail.com','9515744884','Driver','pbkdf2_sha256$600000$d6IHbAhZhsuA4voOHgVn7F$VVMkRqYA8NB0FVopiZ4TUD2SmSWzJHUBhjp2Mhjd7UQ='),(9,'AKSHAW','Akshay Reddy','Rsdnarmad@12','mucheliakshay.reddy2021@vitstudent.ac.in','8688455868','User','pbkdf2_sha256$720000$pzBMEqEWhRVB2wKYxc47ex$S1PMALDju6j8MIpj/9ecUnegC5Yd9U3DDfvbZXdl3vc=');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-22  9:23:51
