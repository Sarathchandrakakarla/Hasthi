from django.apps import AppConfig


class ImportExcelDbConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'import_excel_db'
